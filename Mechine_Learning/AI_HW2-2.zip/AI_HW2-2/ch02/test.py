import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

class Adaline:
    def __init__(self, eta=0.01, n_iter=50):
        self.eta = eta
        self.n_iter = n_iter
        self.weights = None
        self.cost = []

    def fit(self, X, y):
        self.weights = np.zeros(1 + X.shape[1])
        for _ in range(self.n_iter):
            output = self.net_input(X)
            errors = (y - output)
            self.weights[1:] += self.eta * X.T.dot(errors)
            self.weights[0] += self.eta * errors.sum()
            cost = (errors**2).sum() / 2.0
            self.cost.append(cost)
        return self

    def net_input(self, X):
        return np.dot(X, self.weights[1:]) + self.weights[0]

    def activation(self, X):
        return self.net_input(X)

    def predict(self, X):
        return np.where(self.activation(X) >= 0.0, 1, -1)

def plot_cost_function(cost):
    plt.plot(range(1, len(cost) + 1), cost, marker='o')
    plt.xlabel('Epochs')
    plt.ylabel('Sum-squared-error')
    plt.title('Cost function')
    plt.show()

# Load iris dataset
iris = datasets.load_iris()
X = iris.data[:, [1, 3]]  # Sepal Width and Petal Width
y = iris.target

# Select only setosa and versicolor classes
X = X[(y == 0) | (y == 1)]
y = y[(y == 0) | (y == 1)]
y = np.where(y == 0, -1, 1)

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1, stratify=y)

# Standardize features
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

# Initialize and train Adaline
eta_values = [0.01, 0.0001]
n_iter_values = [10, 100]

for eta, n_iter in zip(eta_values, n_iter_values):
    ada = Adaline(eta=eta, n_iter=n_iter)
    ada.fit(X_train_std, y_train)
    plot_cost_function(ada.cost)
    print(f"Adaline with eta={eta}, n_iter={n_iter}")
    print(f"Weights after training: {ada.weights}")

# Plot decision regions
from matplotlib.colors import ListedColormap

def plot_decision_regions(X, y, classifier, resolution=0.02):
    markers = ('s', 'x', 'o', '^', 'v')
    colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
    cmap = ListedColormap(colors[:len(np.unique(y))])

    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.3, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim(xx2.min(), xx2.max())

    for idx, cl in enumerate(np.unique(y)):
        plt.scatter(x=X[y == cl, 0],
                    y=X[y == cl, 1],
                    alpha=0.8,
                    c=colors[idx],
                    marker=markers[idx],
                    label=cl,
                    edgecolor='black')

# Plot decision regions for the best model
ada_best = Adaline(eta=0.01, n_iter=100)
ada_best.fit(X_train_std, y_train)
plot_decision_regions(X_train_std, y_train, classifier=ada_best)
plt.xlabel('Sepal Width (standardized)')
plt.ylabel('Petal Width (standardized)')
plt.legend(loc='upper left')
plt.title('Adaline - Training set')
plt.show()
